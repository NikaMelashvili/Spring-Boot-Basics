package com.exam.nikolozmelashvili.model.entity.dto;

import lombok.Data;

@Data
public class FlightDTO {
    private int id;
    private String flightNumber;
    private Integer city;
}
