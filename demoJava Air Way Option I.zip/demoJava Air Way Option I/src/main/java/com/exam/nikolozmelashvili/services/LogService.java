package com.exam.nikolozmelashvili.services;

import org.springframework.stereotype.Service;

@Service
public class LogService {

    public void logMethodInvocation() {
    }

    public void logMethodReturn() {
    }
}

