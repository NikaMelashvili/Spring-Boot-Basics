package com.exam.nikolozmelashvili;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJavaAirWayOptionIApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoJavaAirWayOptionIApplication.class, args);
    }

}
