package com.exam.nikolozmelashvili.model.entity.dto;

import lombok.Data;

@Data
public class CityDTO {
    private int id;
    private String name;
    private Integer population;
}
