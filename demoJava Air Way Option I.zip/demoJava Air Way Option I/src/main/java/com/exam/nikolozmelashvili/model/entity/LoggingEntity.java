package com.exam.nikolozmelashvili.model.entity;

public class LoggingEntity {

    private Integer id;

    private String loggerName;

    private String
}
