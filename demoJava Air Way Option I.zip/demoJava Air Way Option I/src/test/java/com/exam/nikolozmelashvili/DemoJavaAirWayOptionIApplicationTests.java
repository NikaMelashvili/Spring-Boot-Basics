package com.exam.nikolozmelashvili;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJavaAirWayOptionIApplicationTests {

    @Test
    void contextLoads() {
    }

}
